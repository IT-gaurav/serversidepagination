const express = require("express");
var cors = require('cors')
const app = express();
app.use(cors())

const users = [
  { id: 1, name: "User 1", companyName:'Nep' },
  { id: 2, name: "User 2", companyName:'Nep' },
  { id: 3, name: "User 3", companyName:'Nep' },
  { id: 4, name: "User 4", companyName:'Nep' },
  { id: 5, name: "User 5", companyName:'Nep' },
  { id: 6, name: "User 6", companyName:'Nep' },
  { id: 7, name: "User 7", companyName:'Nep' },
  { id: 8, name: "User 8", companyName:'Nep' },
  { id: 9, name: "User 9", companyName:'Nep' },
  { id: 10, name: "User 10", companyName:'Nep' },
  { id: 11, name: "User 11", companyName:'Nep' },
  { id: 12, name: "User 12", companyName:'Nep' },
  { id: 13, name: "User 13", companyName:'Nep' },
  { id: 14, name: "User 14", companyName:'Nep' },
];

app.get("/", paginatedResults(users), (req, res) => {
  res.json(res.paginatedResults);
});

function paginatedResults(model) {
  return (req, res, next) => {
    const page = +req.query.page;
    const limit = +req.query.limit;

    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;

    const results = {};

    if (endIndex < model.length) {
      results.next = {
        page: page + 1,
        limit: limit,
      };
    }

    if (startIndex > 0) {
      results.previous = {
        page: page - 1,
        limit: limit,
      };
    }

    results.results = model.slice(startIndex, endIndex);

    res.paginatedResults = results;
    next();
  };
}

app.listen(5000);
