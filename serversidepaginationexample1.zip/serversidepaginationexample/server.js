const express = require("express");
var cors = require('cors')
const app = express();
app.use(cors())
const axios = require('axios')



app.get("/", async (req, res) => {
  //res.json(res.paginatedResults);
  let model = (await axios.get('https://jsonplaceholder.typicode.com/posts')).data


  const page = +req.query.page;
  const limit = +req.query.limit;

  const startIndex = (page - 1) * limit;
  const endIndex = page * limit;

  const results = {};

  if (endIndex < model.length) {
    results.next = {
      page: page + 1,
      limit: limit,
      total: model.length
    };
  }

  if (startIndex > 0) {
    results.previous = {
      page: page - 1,
      limit: limit,
    };
  }

  results.results = model.slice(startIndex, endIndex);

  return res.json(results)

});


app.listen(2000);
